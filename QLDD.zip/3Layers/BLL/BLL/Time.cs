﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class Time
    {
        DateTime time = new DateTime();
        public int ngay()
        {
            int ngay;
            time = DateTime.Now;
            ngay = time.Day;
            return ngay;
        }
        public int thang()
        {
            int thang;
            time = DateTime.Now;
            thang = time.Month;
            return thang;
        }
        public int nam()
        {
            int nam;
            time = DateTime.Now;
            nam = time.Year;
            return nam;
        }
        public string homnay()
        {
            string td;
            td = "Ngày "+ ngay() + " tháng " + thang() + " năm " + nam();
            return td;
        }
    }
}
