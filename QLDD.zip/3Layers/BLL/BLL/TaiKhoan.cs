﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DTO;

namespace BLL
{
    public class TaiKhoanBLL
    {
        TaiKhoanAccess tkAccess = new TaiKhoanAccess();
        public string ChecklogicSV(TaiKhoan taikhoan)
        {
            // Kiểm tra Nhap liệu 
            if (taikhoan.MASV == "")
            {
                return "requeid_taikhoan";
            }
            if (taikhoan.MK == "")
            {
                return "requeid_password";
            }
            string info = tkAccess.ChecklogicSV(taikhoan);
            return info;
        }
        public string ChecklogicGV(GV taikhoan)
        {
            // Kiểm tra Nhap liệu 
            if (taikhoan.MAGV == "")
            {
                return "requeid_taikhoan";
            }
            if (taikhoan.MK == "")
            {
                return "requeid_password";
            }
            string info = tkAccess.ChecklogicGV(taikhoan);
            return info;
        }
        public TaiKhoanSV[] GetListSV()
        {
            return tkAccess.GetList();
        }
        public MHHT[] GetListMHHT()
        {
            return tkAccess.GetListMHHT();
        }
        public GV GetGV(string MAGV)
        {
            return tkAccess.GetGV(MAGV);
        }
        public TaiKhoan GetSv(string MASV)
        {
            return tkAccess.GetSV(MASV);
        }
        public MonHoc GetMonHoc(string MAMON)
        {
            return tkAccess.GetMonHoc(MAMON);
        }
        public TTMHt GetTTMH(string MAMON)
        {
            return tkAccess.GetTTMH(MAMON);
        }
        public bool DDSV(TaiKhoan sv,string MAMON,string Lydo,DateTime time,string z,int x)
        {
            return tkAccess.DDSV(sv,GetTTMH(MAMON),Lydo,time,z,x);
        }
        public bool UDDSV(TaiKhoan sv,DateTime time,string text,string mamon)
        {
            return tkAccess.UDDSV(sv,time,text,mamon);
        }
        public bool KTDD(string MASV,string MAMON,DateTime date)
        {
            return tkAccess.KTDD(MASV,MAMON,date);
        }
        public bool TDMKSV(TaiKhoan sv)
        {
            return tkAccess.TDMKSV(sv);
        }
        public DD[] getDD(string MAMON,DateTime time)
        {
            return tkAccess.GetListDD(MAMON, time);
        }
        public bool TDMKGV(GV gv)
        {
            return tkAccess.TDMKGV(gv);
        }
        public bool NLD(TaiKhoan sv, string text,DateTime Time)
        {
            return tkAccess.NLD(sv,text,Time);
        }
        public int CKTDD(int dd,string mamon,DateTime time)
        {
            return tkAccess.DKTDD(dd,mamon,time);
        }
    }
}
