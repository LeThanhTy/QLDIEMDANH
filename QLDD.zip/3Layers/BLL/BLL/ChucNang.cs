﻿using DAL;
using DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class Chucnang
    {
        DatabaseAccess SV = new DatabaseAccess();


        public void UpdateSV(string masv, string hoten, string mk, string gt, string ngsinh, string malop,string diachi)
        {
            SV.UpdateSV(masv, hoten, mk, gt, ngsinh, malop, diachi);
        }
        public void UpdateGV(string magv, string hoten, string mk, string gt, string ngsinh, string diachi)
        {
            SV.UpdateGV(magv,hoten,mk,gt,ngsinh,diachi);
        }
        public void UpdateTTMH(string mamon, DateTime ngaybd, DateTime ngaykt,string tgbd, string tgkt)
        {
            SV.UpdateTTMH(mamon,ngaybd,ngaykt,tgbd,tgkt);
        }
    }
}
