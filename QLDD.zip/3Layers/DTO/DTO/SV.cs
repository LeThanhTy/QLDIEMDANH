﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class TaiKhoan
    {
        public string MASV { set; get; }
        public string MK { set; get; }
        public string TenSV { set; get; }
        public string GT { get; set; }
        public DateTime NGAYSINH { get; set; }
        public string DIACHI { get; set; }
        public int MaQuyen { set; get; }
        public string MaLOP { set; get; }        
    }
    public class TaiKhoanSV
    {   
        public string MASV { set; get; }
        public string TenSV { set; get; }
        public string MaLOP { set; get; }  
    }
}
