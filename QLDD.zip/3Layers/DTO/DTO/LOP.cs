﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class LOP
    {
        public string MAGV { get; set; }
        public string TENGV { get; set; }
        public string MALOP { get; set; }
        public string TENLOP { get; set; }
        public int SOLUONGSV { get; set; }
    }
}
