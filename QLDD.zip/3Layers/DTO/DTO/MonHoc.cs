﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class MonHoc
    {
        public string MAMON { get; set; }
        public string TENMON { get; set; }
        public DateTime TGDR { get; set; }
	    public DateTime TGKT { get; set; }
    }
    public class MHHT
    {
        public string MAMON { get; set; }
        public string TENMON { get; set; }
    }
}
