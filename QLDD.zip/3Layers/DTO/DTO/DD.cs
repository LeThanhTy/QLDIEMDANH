﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public  class DD
    {
        public string MASV { get; set; }
        public string TENSV { get; set; }
        public string DIEMDANH  { get; set; }
        public DateTime NGAYDD  { get; set; }
        public TimeSpan TGDD  { get; set; }
        public string Lydo { get; set; }
    }
}
