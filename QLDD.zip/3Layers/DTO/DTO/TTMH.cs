﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
	public class TTTMH
	{
		public string MAMON { get; set; }
		public string TENMON { get; set; }
		public string MAGV { get; set; }
		public string TENGV { get; set; }
		public DateTime NGAYBD { get; set; }
		public DateTime NGAYKT { get; set; }
	}
	public class TTMHt
	{
		public string MAMON { get; set; }
		public string TENMON { get; set; }
		public string TENGV { get; set; }
		public DateTime NGAYBD { get; set; }
		public DateTime NGAYKT { get; set; }
	}
}
