﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class GV
    {
        public string MAGV { get; set; }
        public string MK { get; set; }
        public string TENGV { get; set; }
        public int MAQUYEN { get; set; }
        public string GT { get; set; }
        public DateTime NGAYSINH { get; set; }
        public string DIACHI { get; set; }
        public string MAMON { get; set; }
        public string TENMON { get; set; }
    }
    public class TTGV
    {
        public string MAGV { get; set; }
        public string MK { get; set; }
        public string TENGV { get; set; }
    }
}
