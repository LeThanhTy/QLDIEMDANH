﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using DTO;
namespace GUI
{
    public partial class TDTTSV : Form
    {
        TaiKhoan tk = new TaiKhoan();
        TaiKhoanBLL taiKhoan = new TaiKhoanBLL();

        string masv,mk,ten;
        public TDTTSV()
        {
            InitializeComponent();
        }
        public TDTTSV(string MASV)
        {
            masv = MASV;
            InitializeComponent();
            tk = taiKhoan.GetSv(masv);
            mk = tk.MK;
            ten = tk.TenSV;
        }
        Chucnang sv = new Chucnang();
        private void TDTTSV_Load(object sender, EventArgs e)
        {
            tk = taiKhoan.GetSv(masv);
            label1.Text = "Mã sinh viên: " + tk.MASV;
            label2.Text = "Mật khẩu hiện tại: " +tk.MK;
            label3.Text = "Mã lớp học: " + tk.MaLOP;
            label4.Text = "Tên sinh viên: " +tk.TenSV;
            label8.Text = "Địa chỉ: "+tk.DIACHI;
            label9.Text = "Giới tính: "+tk.GT;
            label10.Text= "Ngày Sinh: "+Convert.ToDateTime(tk.NGAYSINH).ToString("dd/MM/yyyy");
            textBox1.Text = tk.TenSV;
            textBox2.Text = tk.MK;
            textBox3.Text = tk.MaLOP;
            textBox4.Text = tk.DIACHI;
            if (tk.GT == "Nam") radioButton1.Checked = true;
            else radioButton2.Checked = true;
            dateTimePicker1.Value = tk.NGAYSINH;
        }

        public String CheckGioiTinh()
        {
            string gioitinh = "";
            if (radioButton1.Checked == true) { gioitinh = "Nam"; }
            else if (radioButton2.Checked == true) { gioitinh = "Nữ"; }
            return gioitinh;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                tk = taiKhoan.GetSv(masv);
                label1.Text = "Mã sinh viên: " + tk.MASV;
                sv.UpdateSV(tk.MASV, textBox1.Text, this.textBox2.Text, this.CheckGioiTinh(), this.dateTimePicker1.Value.ToShortDateString(), textBox3.Text, textBox4.Text);
                MessageBox.Show("Sửa thành công","Thông báo",MessageBoxButtons.OK ,MessageBoxIcon.Information);
                TDTTSV_Load(sender, e);
            }
            catch (Exception)
            {
                MessageBox.Show("Sửa không thành công","Thông báo",MessageBoxButtons.OK ,MessageBoxIcon.Error);
                return;
            }
        }
    }
}
