﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using DTO;

namespace GUI 
{
    public partial class TDTTGV: Form
    {
        TaiKhoanBLL TaiKhoan = new TaiKhoanBLL();
        string magv;
        GV gv = new GV();
        public TDTTGV()
        {
            InitializeComponent();
        }
        public TDTTGV(string MAGV)
        {
            magv = MAGV;
            InitializeComponent();
            gv = TaiKhoan.GetGV(MAGV);
        }
        Chucnang GV = new Chucnang();
        private void TDTTGV_Load(object sender, EventArgs e)
        {
            gv = TaiKhoan.GetGV(magv);
            label1.Text = "Mã giáo viên: " + gv.MAGV;
            label2.Text = "Mật khẩu hiện tại: " + gv.MK;
            label3.Text = "Tên giáo viên: " + gv.TENGV;
            label4.Text = "Giới tính: " + gv.GT;
            label8.Text = "Ngày sinh: " + Convert.ToDateTime(gv.NGAYSINH).ToString("dd/MM/yyyy");
            label9.Text = "Địa chỉ: " + gv.DIACHI;
            textBox1.Text = gv.TENGV;
            textBox2.Text = gv.MK;
            textBox3.Text = gv.DIACHI;
            if (gv.GT == "Nam") radioButton1.Checked = true;
            else radioButton2.Checked = true;
            dateTimePicker1.Value = gv.NGAYSINH;
        }
        public String CheckGioiTinh()
        {
            string gioitinh = "";
            if (radioButton1.Checked == true) { gioitinh = "Nam"; }
            else if (radioButton2.Checked == true) { gioitinh = "Nữ"; }
            return gioitinh;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                gv = TaiKhoan.GetGV(magv);
                label1.Text = "Mã giáo viên: " + gv.MAGV;
                GV.UpdateGV(gv.MAGV, textBox1.Text, this.textBox2.Text, this.CheckGioiTinh(), this.dateTimePicker1.Value.ToShortDateString(), textBox3.Text);
                MessageBox.Show("Sửa đổi thành công","Thông báo",MessageBoxButtons.OK,MessageBoxIcon.Information);
                TDTTGV_Load(sender, e);
            }
            catch (Exception)
            {
                MessageBox.Show("Sửa đổi không thành công","Thông báo",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }

        }

    }
}
