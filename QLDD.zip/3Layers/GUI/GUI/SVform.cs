﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using DTO;
namespace GUI
{
    public partial class SVform : Form
    {
        public string masv;
        public string mamh;
        TaiKhoanBLL TaiKhoan = new TaiKhoanBLL();
        public SVform()
        {
            InitializeComponent();

        }
        public SVform(string MASV)
        {
            masv = MASV;
            InitializeComponent();

        }
        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form form = new GUI.TDTTSV(masv);
            form.Show();
        }

        private void SVform_Load(object sender, EventArgs e)
        {
            TTMHt mh = new TTMHt();
            Time time = new Time();
            label1.Text = "Hôm nay: " + time.homnay() +"  -  "+ DateTime.Now.ToString("dd/MM/yyyy");
            try
            {
                Loaddata();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error while loading data",
                    MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
        }
        void Loaddata()
        {
            dataGridView1.DataSource = TaiKhoan.GetListMHHT();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            int here = dataGridView1.CurrentRow.Index;
            mamh = dataGridView1.Rows[here].Cells[0].Value.ToString();
            Form form = new GUI.TTMH(mamh,masv);
            form.Show();
        }


    }
}
