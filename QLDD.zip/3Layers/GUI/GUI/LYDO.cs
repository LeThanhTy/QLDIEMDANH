﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using DTO;
namespace GUI
{
    public partial class LYDO : Form
    {
        TaiKhoanBLL tk = new TaiKhoanBLL();
        string msv;
        DateTime Time;
        public LYDO()
        {
            InitializeComponent();
        }
        public LYDO(string masv,DateTime time)
        {
            msv = masv;
            Time = time;
            InitializeComponent();
            this.Click += button1_Click; 
        }
        private void button1_Click(object sender, EventArgs e)
        {

            TaiKhoan taiKhoan = tk.GetSv(msv);
            try
            {
                tk.NLD(taiKhoan, richTextBox1.Text,Time);
                MessageBox.Show("Nộp thành công!","Thông báo",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
            catch(Exception)
            {
                MessageBox.Show("Nộp không thành công!","Thông báo",MessageBoxButtons.OK,MessageBoxIcon.Information);
                return;
            }
        }
    }
}
