﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using DTO;
namespace GUI
{
    public partial class TDMH : Form
    {
        string mgv;
        TaiKhoanBLL TaiKhoan = new TaiKhoanBLL();
        GV gv = new GV();
        TTMHt ttmh = new TTMHt();
        public TDMH()
        {
            InitializeComponent();
        }
        public TDMH(string magv)
        {
            mgv = magv; 
            InitializeComponent();

        }
        Chucnang cn = new Chucnang();
        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                string tgbd = textBox1.Text + ":" + textBox2.Text + ":" + textBox3.Text;
                string tgkt = textBox4.Text + ":" + textBox5.Text + ":" + textBox6.Text;
                cn.UpdateTTMH(ttmh.MAMON, dateTimePicker1.Value, dateTimePicker1.Value, tgbd, tgkt);
                TDMH_Load(sender, e);
                MessageBox.Show("Thay đổi thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception)
            {
                MessageBox.Show("Thời gian không hợp lệ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void TDMH_Load(object sender, EventArgs e)
        {
            gv = TaiKhoan.GetGV(mgv);
            ttmh = TaiKhoan.GetTTMH(gv.MAMON);
            label2.Text = "Mã môn: " + gv.MAMON;
            label3.Text = "Ngày bắt đầu: " +ttmh.NGAYBD.ToString("dd/MM/yyyy");
            label4.Text = "Ngày kết thúc: "+ttmh.NGAYKT.ToString("dd/MM/yyyy");
            label5.Text = "Thời gian diễn ra điểm danh: " + ttmh.NGAYBD.TimeOfDay.ToString();
            label6.Text = "Thời gian kết thúc điểm danh: "+ttmh.NGAYKT.TimeOfDay.ToString();
            label12.Text = ttmh.TENMON;
            dateTimePicker1.Value = ttmh.NGAYBD;
            textBox1.Text = ttmh.NGAYBD.Hour.ToString();
            textBox4.Text = ttmh.NGAYKT.Hour.ToString();
            textBox2.Text = ttmh.NGAYBD.Minute.ToString();
            textBox3.Text = ttmh.NGAYBD.Second.ToString();
            textBox5.Text = ttmh.NGAYKT.Minute.ToString();
            textBox6.Text = ttmh.NGAYKT.Second.ToString();
        }
        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!Char.IsDigit(e.KeyChar) & !Char.IsControl(e.KeyChar) && e.KeyChar != (Char)Keys.Back && (e.KeyChar != '.'))
                e.Handled = true;

        }
    }
}
