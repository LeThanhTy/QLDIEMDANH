﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using DTO;

namespace GUI
{

    public partial class GVform : Form
    {
        int y = 1, z = 2;
        string magv;
        TaiKhoanBLL taiKhoan = new TaiKhoanBLL();
        GV gv = new GV();
        public GVform()
        {
            InitializeComponent();
            this.Load += GVform_Load;
        }
        public GVform(string MAGV) 
        {
            magv = MAGV;
            gv = taiKhoan.GetGV(magv);
            InitializeComponent();
            this.Load += GVform_Load; 
            label2.Text = "Đã điểm danh: "+taiKhoan.CKTDD(y,gv.MAMON,dateTimePicker1.Value).ToString();
            label3.Text = "Vắng: "+taiKhoan.CKTDD(z,gv.MAMON,dateTimePicker1.Value).ToString();
        }
        private void GVform_Load(object sender, EventArgs e)
        {
            try
            {
                LoadData();
            }

            catch (Exception)
            {
                MessageBox.Show("Tải dữ liệu không thành công!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        void LoadData()
        {
            dataGridView1.DataSource = taiKhoan.getDD(gv.MAMON,dateTimePicker1.Value.Date);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form form = new GUI.TDTTGV(magv);
            form.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form tdmh = new GUI.TDMH(magv);
            tdmh.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                LoadData();
                label2.Text = "Đã điểm danh: " + taiKhoan.CKTDD(y, gv.MAMON, dateTimePicker1.Value).ToString();
                label3.Text = "Vắng: " + taiKhoan.CKTDD(z, gv.MAMON, dateTimePicker1.Value).ToString();
            }
            catch (Exception)
            {
                MessageBox.Show("Tải dữ liệu không thành công!","Thông báo",MessageBoxButtons.OK ,MessageBoxIcon.Error);
                return;
            }
        }
    }
}
