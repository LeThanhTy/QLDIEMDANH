﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DTO;
using BLL;

namespace GUI
{
    public partial class Login : Form
    {
        GV gv = new GV();
        TaiKhoan taikhoan = new TaiKhoan();
        TaiKhoanBLL TKBLL = new TaiKhoanBLL();
        public Login()
        {
            InitializeComponent();
            textBox2.PasswordChar = '*';
        }


        private void button1_Click(object sender, EventArgs e)
        {
            taikhoan.MASV = textBox1.Text;
            taikhoan.MK = textBox2.Text;
            gv.MAGV = textBox1.Text;
            gv.MK = textBox2.Text;
            if (radioButton1.Checked == true)
            {
                string getuser = TKBLL.ChecklogicSV(taikhoan);
                switch (getuser)
                {
                    case "requeid_taikhoan":
                        MessageBox.Show("Tài khoản không được để trống");
                        return;

                    case "requeid_password":
                        MessageBox.Show("Mật Khẩu không được để trống");
                        return;

                    case "Không chính xác!":
                        MessageBox.Show("Không chính xác!");
                        return;
                }

                MessageBox.Show("Đăng nhập thành công","Thông báo",MessageBoxButtons.OK,MessageBoxIcon.Information);
                Form form = new GUI.SVform(taikhoan.MASV);
                form.Show();
            }
            else
            if (radioButton2.Checked == true)
            {
                string getuser = TKBLL.ChecklogicGV(gv);
                switch (getuser)
                {
                    case "requeid_taikhoan":
                        MessageBox.Show("Tài khoản không được để trống");
                        return;

                    case "requeid_password":
                        MessageBox.Show("Mật Khẩu không được để trống");
                        return;

                    case "Không chính xác!":
                        MessageBox.Show("Không chính xác!");
                        return;
                }
                MessageBox.Show("Đăng Nhập thành công","Thông báo",MessageBoxButtons.OK,MessageBoxIcon.Information);
                Form form = new GUI.GVform(gv.MAGV);
                form.Show();
            }
            else MessageBox.Show("Chưa chọn chức vụ để đăng nhập!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                textBox2.PasswordChar = (char)0;
            }
            else
            {
                textBox2.PasswordChar = '*';
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar)&!Char.IsControl(e.KeyChar) && !Char.IsNumber(e.KeyChar) && e.KeyChar != (Char)Keys.Back)
                e.Handled = true;

        }
    }
}
