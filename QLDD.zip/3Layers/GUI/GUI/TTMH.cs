﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BLL;
using DTO;
namespace GUI
{
    public partial class TTMH : Form
    {
        int x = 1, y = 2;
        TaiKhoanBLL TaiKhoan = new TaiKhoanBLL();
        TTMHt mHHT = null;
        string mamh, masv;
        public TTMH()
        {
            InitializeComponent();
        }
        public TTMH(string MAMH, string MASV)
        {
            mamh = MAMH;
            masv = MASV;
            InitializeComponent();
            this.Load += TTMH_Load;
        }

        private void TTMH_Load(object sender, EventArgs e)
        {

            label1.Text = "Mã môn học: " + mamh;
            mHHT = TaiKhoan.GetTTMH(mamh);
            label2.Text = mHHT.TENMON;
            label3.Text = "Ngày bắt đầu: " + mHHT.NGAYBD.ToShortDateString();
            label4.Text = "Ngày kết thúc: " + mHHT.NGAYKT.ToShortDateString();
            label5.Text = "Giảng viên: " + mHHT.TENGV;
            label6.Text = "Thời gian bắt đầu điểm danh: " + mHHT.NGAYBD.TimeOfDay.ToString();
            label7.Text = "Thời gian kết thúc điểm danh: " + mHHT.NGAYKT.TimeOfDay.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime time = new DateTime();
            time = DateTime.Now;
            mHHT = TaiKhoan.GetTTMH(mamh);
            TaiKhoan sv = TaiKhoan.GetSv(masv);
            try
            {
                if (DateTime.Now.Date.CompareTo(mHHT.NGAYBD.Date)==0)
                {
                    if (DateTime.Now.Hour >= mHHT.NGAYBD.Hour && DateTime.Now.Hour <= mHHT.NGAYKT.Hour)
                    {
                        if (TaiKhoan.KTDD(masv, mamh,time))
                        {
                             MessageBox.Show("Đã điểm danh rồi!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            TaiKhoan.DDSV(sv, mamh, "Đã điểm danh", time, time.ToLongTimeString(), x);
                            MessageBox.Show("Điểm danh thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    if (DateTime.Compare(DateTime.Now.ToLocalTime(), mHHT.NGAYKT.ToLocalTime()) > 0)
                    {
                        TaiKhoan.DDSV(sv, mamh, "Vắng", mHHT.NGAYKT, time.ToLongTimeString(), y);
                        DialogResult result = MessageBox.Show("Buổi học đã kết thúc!" + "\nBạn có muốn ghi lý do vắng mặt không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                        if (result == DialogResult.Yes)
                        {
                            Form form = new GUI.LYDO(masv, mHHT.NGAYKT);
                            form.Show();
                            Close();
                        }
                        else Close();
                    }
                    else
                    {
                        MessageBox.Show("Buổi học chưa diễn ra!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                if (DateTime.Compare(DateTime.Now.Date,mHHT.NGAYKT.Date) > 0 )
                {
                    if (TaiKhoan.KTDD(masv, mamh,time))
                    {
                        MessageBox.Show("Đã điểm danh rồi!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        TaiKhoan.DDSV(sv, mamh, "Vắng",mHHT.NGAYKT,time.ToLongTimeString(),y);
                        DialogResult result = MessageBox.Show("Buổi học đã kết thúc!" + "\nBạn có muốn ghi lý do vắng mặt không?", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                        if (result == DialogResult.Yes)
                        {
                            Form form = new GUI.LYDO(masv, mHHT.NGAYKT);
                            form.Show();
                            Close();
                        }
                        else Close();
                    }
                }
                else
                {
                    MessageBox.Show("Buổi học chưa diễn ra!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Điểm danh không thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            Close();
        }
    }
}
