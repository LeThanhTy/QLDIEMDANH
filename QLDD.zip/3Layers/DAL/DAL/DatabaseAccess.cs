﻿using DTO;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DAL
{
    
    public class SqlConnectionData {
        // Tạo chuỗi kết nối cơ sở dữ liệu SQL sever
        public static SqlConnection Connect()
        {
            string strcon = "Data Source=DELL\\SQLEXPRESS;Initial Catalog=QLDIEMDANH;Integrated Security=True";
            SqlConnection connect = new SqlConnection(strcon); // khởi tạo connect
            return connect;
        }
    }
    public class DatabaseAccess
    {
        public void ExecuteNonQuery(string query)
        {
            SqlConnection connect = SqlConnectionData.Connect();
            SqlCommand command = new SqlCommand(query, connect);

            try
            {
                connect.Open();
                command.ExecuteNonQuery();
                command.Dispose();
            }
            catch (Exception ex)
            {
                throw new Exception("Lỗi: " + ex.Message);
            }
            finally
            {
                if (connect != null)
                {
                    connect.Close();
                }

                if (command != null)
                {
                    command.Dispose();
                }
            }
        }

        public static string CheckLogicDTOSV(TaiKhoan taiKhoan)
        {
            // Hàm conncet tới CSDL
            string user = null;
            SqlConnection connect = SqlConnectionData.Connect();
            connect.Open();
            SqlCommand command = new SqlCommand("logic", connect);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@user", taiKhoan.MASV);
            command.Parameters.AddWithValue("@pass", taiKhoan.MK);

            // Kiểm tra quyển 
            command.Connection= connect;
            SqlDataReader reader= command.ExecuteReader();
            if (reader.HasRows) { 
                while(reader.Read())
                {
                    user = reader.GetString(0);
                }
                reader.Close();
                connect.Close();
            }
            else
            {

                return "Không chính xác!";
            }
            return user;
        }
        public static string CheckLogicDTOGV(GV taiKhoan)
        {

            // Hàm conncet tới CSDL
            string user = null;
            SqlConnection connect = SqlConnectionData.Connect();
            connect.Open();
            SqlCommand command = new SqlCommand("logicGV", connect);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@user", taiKhoan.MAGV);
            command.Parameters.AddWithValue("@pass", taiKhoan.MK);
            
            // Kiểm tra quyển 
            command.Connection= connect;
            SqlDataReader reader= command.ExecuteReader();
            if (reader.HasRows) { 
                while(reader.Read())
                {
                    user = reader.GetString(0);
                }
                reader.Close();
                connect.Close();
            }
            else
            {

                return "Không chính xác!";
            }
            
            return user;
        }
        public DataTable ExecuteQuery(string query)
        {
            DataTable table = new DataTable();
            SqlConnection connection = SqlConnectionData.Connect();
            try
            {
                connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                adapter.Fill(table);
            }
            catch (Exception ex)
            {
                throw new Exception("Lỗi: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        
            return table;
        }
        public GV GetGV(string MAGV)
        {
            GV gv = new GV();
            SqlConnection connect = SqlConnectionData.Connect();
            connect.Open();
            SqlCommand command = new SqlCommand("TK", connect);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@ma", MAGV);
            command.Connection = connect;
            SqlDataReader reader = command.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    gv.MAGV = reader.GetString(0);
                    gv.MK = reader.GetString(1);
                    gv.TENGV = reader.GetString(2);
                    gv.MAQUYEN = (int)reader.GetValue(5);
                    gv.GT = reader.GetString(3);
                    gv.NGAYSINH = reader.GetDateTime(4);
                    gv.DIACHI = reader.GetString(6);
                    gv.MAMON = reader.GetString(7);
                    gv.TENMON = reader.GetString(8);
                }
                reader.Close();
                connect.Close();
            }
            return gv;
        }
        public TaiKhoan GetSV(string MASV)
        {
            TaiKhoan sv = new TaiKhoan();
            SqlConnection connect = SqlConnectionData.Connect();
            connect.Open();
            SqlCommand command = new SqlCommand("TKSV", connect);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@ma",MASV);
            command.Connection= connect;
            SqlDataReader reader= command.ExecuteReader();
            if (reader.HasRows) { 
                while(reader.Read())
                {
                    sv.MASV = reader.GetString(0);
                    sv.MK = reader.GetString(1);
                    sv.GT = reader.GetString(3);
                    sv.NGAYSINH = reader.GetDateTime(4);
                    sv.MaQuyen = (int)reader.GetValue(5);
                    sv.DIACHI = reader.GetString(6);
                    sv.MaLOP = reader.GetString(7);
                    sv.TenSV = reader.GetString(2);
                }
                reader.Close();
                connect.Close();
            }
            return sv;
        }
        public MonHoc GetMonHoc(string MAMON)
        {
            MonHoc sv = new MonHoc();
            SqlConnection connect = SqlConnectionData.Connect();
            connect.Open();
            SqlCommand command = new SqlCommand("TKMH", connect);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@ma",MAMON);
            command.Connection= connect;
            SqlDataReader reader= command.ExecuteReader();
            if (reader.HasRows) { 
                while(reader.Read())
                {
                    sv.MAMON = reader.GetString(0);
                    sv.TENMON = reader.GetString(1);
                    sv.TGDR = reader.GetDateTime(2);
                    sv.TGKT = reader.GetDateTime(3);
                }
                reader.Close();
                connect.Close();
            }
            return sv;

        }
        public TTMHt GetTTMH(string MAMON)
        {
            TTMHt sv = new TTMHt();
            SqlConnection connect = SqlConnectionData.Connect();
            connect.Open();
            SqlCommand command = new SqlCommand("KTTTMH", connect);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@ma",MAMON);
            command.Connection= connect;
            SqlDataReader reader= command.ExecuteReader();
            if (reader.HasRows) { 
                while(reader.Read())
                {
                    sv.MAMON = reader.GetString(0);
                    sv.TENMON = reader.GetString(1);
                    sv.TENGV = reader.GetString(3);
                    sv.NGAYBD = reader.GetDateTime(4).Add(reader.GetTimeSpan(5));
                    sv.NGAYKT = reader.GetDateTime(6).Add(reader.GetTimeSpan(7));
                }
                reader.Close();
                connect.Close();
            }
            return sv;
        }
        

        public bool KTDD(string MASV,string MAMON,DateTime date)
        {
            SqlConnection connect = SqlConnectionData.Connect();
            connect.Open();
            SqlCommand command = new SqlCommand("KTDD", connect);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@ma",MASV);
            command.Parameters.AddWithValue("@mamon",MAMON);
            command.Parameters.AddWithValue("@d", date.ToString("MM/dd/yyyy"));
            command.Connection= connect;
            SqlDataReader reader= command.ExecuteReader();
            if (reader.HasRows) {
                return true;
            }
            return false;
        }
        public int DKTDD(int Dd,string mamon,DateTime time)
        {
            int count = 0;
            SqlConnection connect = SqlConnectionData.Connect();
            connect.Open();
            SqlCommand command = new SqlCommand("CKTDD", connect);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@ma",Dd);
            command.Parameters.AddWithValue("@mamon",mamon);
            command.Parameters.AddWithValue("@ngay",time.ToShortDateString());
            command.Connection= connect;
            SqlDataReader reader= command.ExecuteReader();
            if (reader.HasRows) {
                while (reader.Read())
                {
                    count++;
                }
            }
            return count;
        }

        public void UpdateSV(string masv, string hoten, string mk, string gt, string ngsinh, string malop, string diachi)
        {
            try
            {
                string sql = "update SV set TENSV = N'" + hoten + "', MK = N'" + mk + "' , GIOITINH = N'" + gt + "', NGAYSINH = N'" + ngsinh + "',MALOP = N'" + malop + "',DIACHI =N'" + diachi + "'  where MASV ='" + masv + "' ";
                string command1 = "UPDATE DD SET TENSV = N'" + hoten + "' WHERE MASV = '" + masv + "'";
                ExecuteNonQuery(sql);
                ExecuteNonQuery(command1);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void UpdateGV(string magv, string hoten, string mk, string gt, string ngsinh, string diachi)
        {
            try
            {
                string sql = "update GV set TENGV = N'" + hoten + "', MK = N'" + mk + "',GIOITINH = N'" + gt + "', NGAYSINH = '" + ngsinh + "',DIACHI =N'" + diachi + "' where MAGV ='" + magv + "' ";
                string command1 = "UPDATE TTMH SET TENGV = N'" + hoten + "' WHERE MAGV = '" + magv + "'";
                string command2 = "UPDATE CLASS SET TENGV = N'" + hoten + "' WHERE MAGV = '" + magv + "'";
                ExecuteNonQuery(sql);
                ExecuteNonQuery(command1);
                ExecuteNonQuery(command2);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public void UpdateTTMH(string mamon, DateTime ngaybd, DateTime ngaykt, string tgbd, string tgkt)
        {
            try
            {
                string sql = "update TTMH set NGAYBD = '" + ngaybd.ToShortDateString() + "', NGAYKT ='" + ngaykt.ToShortDateString() + "',TGBD ='" + tgbd + "', TGKT ='" + tgkt + "' where MAMON = '" + mamon + "'";
                ExecuteNonQuery(sql);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
