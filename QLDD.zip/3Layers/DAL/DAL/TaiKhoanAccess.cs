﻿using DTO;
using DAL;
using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class TaiKhoanAccess : DatabaseAccess
    {
        public string ChecklogicSV(TaiKhoan taiKhoan)
        {
            string info = CheckLogicDTOSV(taiKhoan);
            return info;
        }
        public string ChecklogicGV(GV taiKhoan)
        {
            string info = CheckLogicDTOGV(taiKhoan);
            return info;
        }

        private TaiKhoanSV GetSVFromDataRow(DataRow row)
        {
            TaiKhoanSV sv = new TaiKhoanSV();
            sv.MASV = row["MASV"].ToString();
            sv.TenSV = row["TENSV"].ToString().Trim();
            sv.MaLOP = row["MALOP"].ToString().Trim();
            return sv;
        }
        private MHHT GetMHHT(DataRow row)
        {
            MHHT mhht = new MHHT();
            mhht.MAMON = row["MAMON"].ToString().Trim();
            mhht.TENMON = row["TENMON"].ToString().Trim();
            return mhht;

        }
        private DD GetDD(DataRow row)
        {
            DD mhht = new DD();
            mhht.MASV = row["MASV"].ToString().Trim();
            mhht.TENSV = row["TENSV"].ToString().Trim();
            mhht.DIEMDANH = row["DIEMDANH"].ToString().Trim();
            mhht.NGAYDD = DateTime.Parse(row["NGAYDD"].ToString());
            mhht.TGDD = DateTime.Parse(row["TGDD"].ToString()).TimeOfDay;
            mhht.Lydo = row["GHICHU"].ToString();
            return mhht;

        }

        public TaiKhoanSV[] GetList()
        {
            TaiKhoanSV[] list = null;
            DataTable table = null;
            int n = 0;

            table = ExecuteQuery("select * from SV"); 
            n = table.Rows.Count;

            if (n == 0)
            {
                return null;
            }

            list = new TaiKhoanSV[n];
            for (int i = 0; i < n; i++)
            {
                TaiKhoanSV s = GetSVFromDataRow(table.Rows[i]);
                list[i] = s;
            }

            return list;
        }
        public MHHT[] GetListMHHT()
        {
            MHHT[] list = null;
            DataTable table = null;
            int n = 0;

            table = ExecuteQuery("select * from MONHOC");  
            n = table.Rows.Count;

            if (n == 0)
            {
                return null;
            }

            list = new MHHT[n];
            for (int i = 0; i < n; i++)
            {
                MHHT s = GetMHHT(table.Rows[i]);
                list[i] = s;
            }

            return list;
        }
        public DD[] GetListDD(string magv, DateTime time)
        {

            DD[] list = null;
            DataTable table = null;
            int n = 0;

            table = ExecuteQuery("select * from DD where MAMON='" + magv + "' and NGAYDD = '" + time.Date + "'");  
            n = table.Rows.Count;

            if (n == 0)
            {
                return null;
            }

            list = new DD[n];
            for (int i = 0; i < n; i++)
            {
                DD s = GetDD(table.Rows[i]);
                list[i] = s;
            }

            return list;
        }
        public bool DDSV(TaiKhoan sv, TTMHt tTMHt, string text,DateTime time,string z,int x)
        {
            string command = "INSERT DD(MASV,TENSV,DIEMDANH,MAMON,TENMON,NGAYDD,TGDD,GHICHU,SDD) VALUES ('" + sv.MASV + "',N'" + sv.TenSV + "',N'" + text + "','" + tTMHt.MAMON + "',N'" + tTMHt.TENMON + "','" + time.Date.ToShortDateString() + "','" + z + "','" + " " + "','" + x + "')";
            try
            {
                ExecuteNonQuery(command);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool UDDSV(TaiKhoan sv, DateTime time, string text,string mamon)
        {
            string command = "Update DD set DIEMDANH = N'" + text + "' where masv ='" + sv.MASV +"' and MAMON ='"+mamon+ "' and NGAYDD ='" + time.Date.ToShortDateString() + "'";
            try
            {
                ExecuteNonQuery(command);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        
        public bool TDMKSV(TaiKhoan sv)
        {
            string command = "UPDATE SV SET MK = '" + sv.MK + "' WHERE MASV = '" + sv.MASV + "'";
            try
            {
                ExecuteNonQuery(command);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool TDMKGV(GV gv)
        {
            string command = "UPDATE GV SET MK = '" + gv.MK + "' WHERE MAGV = '" + gv.MAGV + "'";
            try
            {
                ExecuteNonQuery(command);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool NLD(TaiKhoan sv, string text, DateTime time)
        {
            string command = "UPDATE DD SET GHICHU = N'" + text + "' WHERE MASV = '" + sv.MASV + "' and NGAYDD = '" +time.Date.ToShortDateString()+ "'";
            try
            {
                ExecuteNonQuery(command);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

    }
}
